package com.pos.poswarung.printer

import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

class RawTcpPrinter(private val ip: String, private val port: Int = 9100) {

    fun print(text: String): Boolean {
        return try {
            val socket = Socket()
            socket.connect(InetSocketAddress(ip, port), 3000)
            val out: OutputStream = socket.getOutputStream()
            out.write(text.toByteArray(Charsets.UTF_8))
            out.flush()
            socket.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
