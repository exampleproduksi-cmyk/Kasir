package com.pos.poswarung

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.GridView
import androidx.appcompat.app.AppCompatActivity
import com.pos.poswarung.data.AppDatabase
import com.pos.poswarung.data.Item
import com.pos.poswarung.databinding.ActivityMainBinding
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val cart = mutableListOf<Item>()
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        db = AppDatabase.getInstance(applicationContext)

        scope.launch {
            withContext(Dispatchers.IO) {
                if (db.itemDao().count() == 0) {
                    val samples = listOf(
                        Item(0,"Beras 5kg",120000),
                        Item(0,"Minyak 1L",15000),
                        Item(0,"Gula 1kg",12000),
                        Item(0,"Rokok A",25000),
                        Item(0,"Kopi Sachet",3000),
                        Item(0,"Susu 1L",18000)
                    )
                    samples.forEach { db.itemDao().insert(it) }
                }
            }
            refreshProducts()
        }

        binding.gridProducts.setOnItemClickListener { _, _, pos, _ ->
            val item = binding.gridProducts.adapter.getItem(pos) as String
            // simple: match name to item in DB (for demo)
            scope.launch {
                val all = withContext(Dispatchers.IO) { db.itemDao().getAll() }
                val found = all.find { (it.name + " - Rp " + it.price) == item }
                found?.let { addToCart(it) }
            }
        }

        binding.btnPay.setOnClickListener {
            if (cart.isEmpty()) return@setOnClickListener
            scope.launch(Dispatchers.IO) {
                val total = cart.sumOf { it.price }
                db.transactionDao().insert(com.pos.poswarung.data.Transaction(0,System.currentTimeMillis(), total))
                cart.clear()
                withContext(Dispatchers.Main) { refreshCart() }
            }
        }
    }

    private fun refreshProducts() {
        scope.launch {
            val items = withContext(Dispatchers.IO) { db.itemDao().getAll() }
            val adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, items.map{ it.name + " - Rp " + it.price })
            binding.gridProducts.adapter = adapter
        }
    }

    private fun addToCart(item: Item) {
        cart.add(item)
        refreshCart()
    }

    private fun refreshCart() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, cart.map{ it.name + " - Rp " + it.price })
        binding.listCart.adapter = adapter
        val total = cart.sumOf { it.price }
        binding.textTotal.text = "Total: Rp $total"
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
