package com.pos.poswarung.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ItemDao {
    @Query("SELECT * FROM Item")
    fun getAll(): List<Item>

    @Query("SELECT COUNT(*) FROM Item")
    fun count(): Int

    @Insert
    fun insert(item: Item)
}
