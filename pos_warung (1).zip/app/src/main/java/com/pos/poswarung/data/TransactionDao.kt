package com.pos.poswarung.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TransactionDao {
    @Insert
    fun insert(tx: Transaction): Long

    @Query("SELECT * FROM Transaction")
    fun getAll(): List<Transaction>
}
