PosWarung - lightweight POS for small shops (optimized for GitHub Actions build)

How to build on GitHub (no-wrapper):
1. Create a GitHub repository (public) and push this project.
2. Ensure branch 'main' contains these files.
3. The workflow .github/workflows/android-build.yml will run on push or manual dispatch.
4. After workflow completes, download APK from Actions -> Artifacts -> app-debug-apk.

If you want me to push the repo & workflow for you, provide a GitHub repo link or invite collaborator.
